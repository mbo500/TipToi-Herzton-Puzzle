HERZTON-PUZZLE | TIPTOI FERTIG-PAKET
=====================================

Projekt: Herzton-Puzzle / Klavier-Puzzle
Projektnummer: 1738
Team: Micha Börner, Ava Zimmermann, Sami Bourbian, Meo Belloni

WICHTIG
-------
Die Datei, die auf den Tiptoi-Stift kommt, heisst:

  herzton_puzzle.gme

Diese Datei ist in diesem Paket bereits enthalten.

Damit der Stift das gedruckte Blatt erkennt, müssen zusätzlich echte OID-Codes
auf die grauen OID-Felder geklebt oder direkt in das Layout eingebaut werden.
Dafür wird tttool benötigt, weil nur tttool die echten druckbaren OID-Muster
erzeugt.

Ablauf für die Präsentation
---------------------------
1. Druckvorlage aus dem Ordner "druck" ausdrucken.
2. Mit tttool aus der YAML-Datei die OID-Codes erzeugen:

   Windows:
     build_windows.bat ausführen

   Mac/Linux:
     ./build_linux_mac.sh ausführen

   Manuell:
     tttool --dpi 1200 --pixel-size 2 --code-dim 25 oid-table herzton_puzzle.yaml herzton_oid_codes.pdf

3. Die PDF "herzton_oid_codes.pdf" ausdrucken.
4. Die OID-Codes ausschneiden und gemäss "docs/OID_Zuordnung.csv" auf die grauen Felder kleben.
5. Die Datei "herzton_puzzle.gme" per USB auf den Tiptoi-Stift kopieren.
6. Stift sicher auswerfen und neu starten.
7. START-Feld antippen.

Spielablauf
-----------
1. START antippen.
2. Eine unbeschriftete Piano-Taste antippen.
3. Der Stift spielt den Ton.
4. Oben die vermutete Frequenz antippen.
5. Der Stift sagt:
   - Richtig erkannt.
   - Falsch. Zu hoch.
   - Falsch. Zu tief.

OID-Logik
---------
START  = 930
REPLAY = 931
STOP   = 932
NAME   = 933
TON    = 934

Antwortfelder oben:
63 Hz   = 1010
125 Hz  = 1011
250 Hz  = 1012
500 Hz  = 1013
1 kHz   = 1014
2 kHz   = 1015
4 kHz   = 1016
8 kHz   = 1017
16 kHz  = 1018

Piano-Tasten unten:
Taste 1 = 1020 -> 63 Hz
Taste 2 = 1021 -> 125 Hz
Taste 3 = 1022 -> 250 Hz
Taste 4 = 1023 -> 500 Hz
Taste 5 = 1024 -> 1 kHz
Taste 6 = 1025 -> 2 kHz
Taste 7 = 1026 -> 4 kHz
Taste 8 = 1027 -> 8 kHz
Taste 9 = 1028 -> 16 kHz

Hinweis zum Test
----------------
Die GME-Datei wurde softwareseitig erstellt. Ein Test mit echtem Tiptoi-Stift
kann nur mit dem physischen Stift und einem Laserdrucker gemacht werden.
Für die Druckqualität wird ein Laserdrucker mit mindestens 600 dpi empfohlen;
besser sind 1200 dpi und weisses Papier.
