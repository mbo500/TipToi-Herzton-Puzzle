@echo off
REM Herzton-Puzzle bauen
REM Voraussetzung: tttool.exe liegt im gleichen Ordner oder ist im PATH.
REM 1) GME-Datei bauen
REM 2) OID-Code-Tabelle als PDF erzeugen

where tttool.exe >nul 2>nul
if %errorlevel% neq 0 (
  echo tttool.exe wurde nicht gefunden.
  echo Bitte tttool herunterladen und tttool.exe in diesen Ordner legen oder in den PATH aufnehmen.
  pause
  exit /b 1
)

tttool.exe assemble herzton_puzzle.yaml herzton_puzzle.gme
if %errorlevel% neq 0 pause

tttool.exe --dpi 1200 --pixel-size 2 --code-dim 25 oid-table herzton_puzzle.yaml herzton_oid_codes.pdf
if %errorlevel% neq 0 pause

echo Fertig. Kopiere herzton_puzzle.gme auf den Tiptoi-Stift und drucke herzton_oid_codes.pdf aus.
pause
