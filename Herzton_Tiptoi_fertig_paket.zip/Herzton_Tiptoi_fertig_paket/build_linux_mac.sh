#!/usr/bin/env bash
set -e
# Herzton-Puzzle bauen
# Voraussetzung: tttool ist installiert und im PATH.

if ! command -v tttool >/dev/null 2>&1; then
  echo "tttool wurde nicht gefunden. Bitte tttool installieren und erneut ausführen."
  exit 1
fi

tttool assemble herzton_puzzle.yaml herzton_puzzle.gme
tttool --dpi 1200 --pixel-size 2 --code-dim 25 oid-table herzton_puzzle.yaml herzton_oid_codes.pdf

echo "Fertig. Kopiere herzton_puzzle.gme auf den Tiptoi-Stift und drucke herzton_oid_codes.pdf aus."
